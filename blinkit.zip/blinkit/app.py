from flask import Flask, redirect, url_for, render_template, request
import mysql.connector
import atexit


app = Flask(__name__)

# MySQL Configuration
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'YourPassword'
app.config['MYSQL_DB'] = 'blinkit'

# Create a MySQL connection
mysql_conn = mysql.connector.connect(
    host=app.config['MYSQL_HOST'],
    user=app.config['MYSQL_USER'],
    password=app.config['MYSQL_PASSWORD'],
    database=app.config['MYSQL_DB']
)

# Create a cursor for executing SQL queries
cursor = mysql_conn.cursor()


cursor.execute("""
    CREATE TABLE IF NOT EXISTS sigup (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL
    )
""")
mysql_conn.commit()


def close_db():
    cursor.close()
    mysql_conn.close()


atexit.register(close_db)


@app.route('/')
def signup():
    return render_template('signup.html')


@app.route('/submit_signup', methods=['POST'])
def submit_signup():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']

        try:
            cursor.execute(
                "INSERT INTO signup (username, email, password) VALUES (%s, %s, %s)",
                (username, email, password)
            )
            mysql_conn.commit()

            return redirect(url_for('main_page'))

        except mysql.connector.Error as err:
            print(f"Error: {err}")

    return render_template('signup.html')


@app.route('/main')
def main_page():

    return render_template('main.html')


@app.route('/grossery')
def grossery_page():

    return render_template('grossery.html')


@app.route('/makeup')
def makeup_page():

    return render_template('makeup.html')


@app.route('/electroinc_items')
def electroinc_items_page():

    return render_template('electroinc_items.html')


@app.route('/milk')
def milk_page():

    return render_template('milk.html')


@app.route('/vegetable')
def vegetable_page():

    return render_template('vegetable.html')


@app.route('/softdrinks')
def softdrinks_page():

    return render_template('softdrinks.html')


if __name__ == '__main__':
    app.run(debug=True)
